﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ViewComponents30.Models;

namespace ViewComponents30.ViewComponents
{
    public class ProductItemViewComponent : ViewComponent
    {
        

        public IViewComponentResult Invoke(int productId)
        {
            ProductItem item = new ProductItem();
            var productItems = item.GetItems();
            var itemSelected = productItems.FirstOrDefault(x => x.Id == productId);
            //return View("ProductItems", productItems);
            return View(itemSelected); 
        }
    }
}
