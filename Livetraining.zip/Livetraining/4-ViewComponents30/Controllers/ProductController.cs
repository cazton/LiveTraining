﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ViewComponents30.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index()
        {
            List<int> list = new List<int>{1, 2, 3, 4};
            return View(list);
        }
    }
}