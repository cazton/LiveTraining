﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EfcoreStart.Data
{
    public class CaztonContext : DbContext
    {
        public CaztonContext(DbContextOptions<CaztonContext> options)
        : base(options)
        {
            
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Model { get; set; }
    }

    public class Order
    {
        public int Id { get; set; }
        public List<Product> Products { get; set; }
    }
}
