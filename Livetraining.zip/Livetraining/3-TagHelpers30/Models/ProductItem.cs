﻿using System.Collections.Generic;

namespace TagHelpers30.Models
{
    public class ProductItem
    {
        public int Id;
        public string Name;
        public string Description;
        public decimal Price;
        public string ImageName;

        public List<ProductItem> GetItems()
        {
            return new List<ProductItem>
            {
                new ProductItem{ Id = 1, ImageName = "cazton.png", Price=30},
                new ProductItem{ Id =2, ImageName = "cazton.png", Price=400},
                new ProductItem{ Id = 3, ImageName = "cazton.png", Price=570},
                new ProductItem{ Id = 4, ImageName = "cazton.png", Price=3456},
                new ProductItem{ Id = 5, ImageName = "cazton.png", Price=30},
            };
        }
    }
}
