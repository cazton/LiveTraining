﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;
using TagHelpers30.Models;

namespace TagHelpers30.TagHelpers
{
    [HtmlTargetElement("product-item", Attributes = "item")]
    public class ProductItemTagHelper : TagHelper
    {
        public ProductItem Item { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.Add("class", "product-item");

            output.Content.SetHtmlContent(ProductItemContent());
        }

        private string ProductItemContent()
        {
            return $@"<img src = 'images/{Item.ImageName}'/></br>                            
                                    <label>{Item.Name}</label>                              
                                    <label>{Item.Price}</label>                            
                                    <span>{Item.Description}</span>
                                ";
        }
    }
}
