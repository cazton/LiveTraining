﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace TagHelpers30.TagHelpers
{
    [HtmlTargetElement("span")]
    public class HelloworldTagHelper : TagHelper 
    {
        public string ProductName { get; set; }
        public override async void Process(TagHelperContext context, 
            TagHelperOutput output)
        {
            var content = await output.GetChildContentAsync();
            var name = content.GetContent();
            output.Content.SetContent($"hello world {name}");
        }
    }
}
