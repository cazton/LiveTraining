﻿using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace _1_AspnetCore30_Middleware.Core
{
    public class ErrorResult : IActionResult
    {
        private readonly HttpRequestMessage _request;
        private readonly HttpResponseMessage _response;

        public ErrorResult(HttpRequestMessage request, HttpResponseMessage response)
        {
            _request = request;
            _response = response;
        }

        public Task ExecuteResultAsync(ActionContext context)
        {
            _response.RequestMessage = _request;
            _response.StatusCode = HttpStatusCode.InternalServerError;
            return Task.FromResult(_response);
        }
    }
}