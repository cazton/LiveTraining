﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Filters;

namespace _1_AspnetCore30_Middleware.Core
{
    public class ValidateFilter : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            if (context.Exception is ValidationException)
            {
                throw new HttpRequestException("validation exception ****");
            }
        }
    }
}