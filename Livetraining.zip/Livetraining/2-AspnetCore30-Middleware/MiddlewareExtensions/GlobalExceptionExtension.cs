﻿using _1_AspnetCore30_Middleware.Throttling;
using Microsoft.AspNetCore.Builder;

namespace _1_AspnetCore30_Middleware.MiddlewareExtensions
{
    public static class GlobalExceptionExtension
    {
        public static IApplicationBuilder UseGlobalExceptionHandler(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GlobalExceptionMiddleware>();
        }
    }

}
