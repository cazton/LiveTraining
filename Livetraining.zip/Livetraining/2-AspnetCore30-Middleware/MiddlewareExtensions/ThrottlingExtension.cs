﻿using _1_AspnetCore30_Middleware.Throttling;
using Microsoft.AspNetCore.Builder;

namespace _1_AspnetCore30_Middleware.MiddlewareExtensions
{
    public static class ThrottlingExtension
    {
        public static IApplicationBuilder UseThrottling(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ThrottlingMiddleware>();
        }
    }

}
