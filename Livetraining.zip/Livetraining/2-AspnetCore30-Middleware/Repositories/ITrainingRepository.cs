﻿using System.Collections.Generic;
using _1_AspnetCore30_Middleware.Models;

namespace _1_AspnetCore30_Middleware.Repositories
{
    public interface ITrainingRepository
    {
        Training GetTraining(int? id);
        List<Training> GetTrainings(TrainingFilter filter);
        List<int> AddTrainings(List<Training> trainings);
    }
}