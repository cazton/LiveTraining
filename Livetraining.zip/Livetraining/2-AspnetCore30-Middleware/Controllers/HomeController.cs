﻿using System;
using _1_AspnetCore30_Middleware.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace _1_AspnetCore30_Middleware.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        {
        }

        public IActionResult Index()
        {
            //throw new Exception("Developers rocks!");
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
