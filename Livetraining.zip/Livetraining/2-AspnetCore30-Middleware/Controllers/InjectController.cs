using _1_AspnetCore30_Middleware.Injection;
using _1_AspnetCore30_Middleware.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace _1_AspnetCore30_Middleware.Controllers
{
    public class InjectController : Controller
    {
        private readonly ISingletonInstance _singletonInstance;
        private readonly ITransient _transient;
        private readonly IScoped _scoped;
        private readonly ISingleton _singleton;
        private readonly InjectionService _service;

        public InjectController(ISingletonInstance singletonInstance,
            ITransient transient,
            IScoped scoped, ISingleton singleton, InjectionService service)
        {
            _singletonInstance = singletonInstance;
            _transient = transient;
            _scoped = scoped;
            _singleton = singleton;
            _service = service;
        }

        public IActionResult Index()
        {
            ViewBag.Transient = _transient;
            ViewBag.SingletonInstance = _singletonInstance;
            ViewBag.Scoped = _scoped;
            ViewBag.Singleton = _singleton;
            ViewBag.Service = _service;
            return View();
        }
    }
}