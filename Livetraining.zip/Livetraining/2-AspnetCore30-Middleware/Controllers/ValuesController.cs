﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Threading.Tasks;
using _1_AspnetCore30_Middleware.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _1_AspnetCore30_Middleware.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET: api/Values
        [HttpGet]
        //[EnableCors("ChanderCorsPolicy")]

        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Values/5
        [HttpGet("{id}", Name = "Get")]
        [Route("~/chander/{id}")]
        public string Get(int id)
        {
            return $"value is {id}";
        }

        // POST: api/Values
        [HttpPost]
        public Post Post([FromBody]Post post)
        {
            post.Id = 45;
            return post;
        }
        
        // PUT: api/Values/5
        [HttpPut("{id}")]
        public string Put(int id, [FromForm] string value)
        {
            value = "changed value";
            return value; 
        }

        // DELETE: api/Values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
