﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using _1_AspnetCore30_Middleware.Core;
using _1_AspnetCore30_Middleware.Models;
using _1_AspnetCore30_Middleware.Repositories;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;

namespace _1_AspnetCore30_Middleware.Controllers
{
    [Route("Trainings")]
    public class TrainingsController : ControllerBase
    {
        private readonly ITrainingRepository _trainingRepository;

        public TrainingsController(ITrainingRepository trainingRepository)
        {
            _trainingRepository = trainingRepository;
        }

        [Route("")]
        [HttpGet]
        public List<Training> GetTrainings([FromQuery]TrainingFilter filter)
        {
            //throw new Exception("Anything");
            return _trainingRepository.GetTrainings(filter);
        }

        [HttpGet]
        [Route("{id:int}")]
        [ValidateFilter]
        public Training GetTraining(int? id)
        {
            if (id > 100)
            {
                throw new ValidationException("Id can't be greater than 100");
            }
           
            return _trainingRepository.GetTraining(id);

        }

        [HttpPost]
        [Route("{id:int}")]
        public IActionResult AddTraining(int? id, [FromBody]Training training)
        {
            return BadRequest("Please use /trainings and pass one or more than one trainings in the request body");
        }

        [HttpPost]
        [Route("")]
        public IActionResult AddTrainings([FromBody] List<Training> trainings)
        {
            if (trainings == null || trainings.Count == 0)
            {
                return BadRequest();
            }
            var trainingIds = _trainingRepository.AddTrainings(trainings);
            if (trainingIds == null || trainingIds.Count == 0)
            {
                return NotFound();
            }
            if (trainingIds.Count == 1)
            {
                return Created(Request.Path + trainingIds[0], trainings);
            }
            return Created(Request.Path, trainingIds);
        }
    }
}
