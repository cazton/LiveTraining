﻿using System.Collections.Generic;
using _1_AspnetCore30_Middleware.Models;
using Microsoft.AspNetCore.Mvc;

namespace _1_AspnetCore30_Middleware.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DefaultController : ControllerBase
    {
        public DefaultController(IPost employee)
        {
            _employee = employee;
        }

        [HttpGet]
        [Route("posts")]
        public List<Post> Posts()
        {
            return _employee.GetPosts();
        }

        private IPost _employee { get; }
    }
}