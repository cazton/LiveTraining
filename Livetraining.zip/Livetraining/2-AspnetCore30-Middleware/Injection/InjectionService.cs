﻿namespace _1_AspnetCore30_Middleware.Injection
{
    public class InjectionService
    {
        public ITransient Transient { get; }
        public IScoped Scoped { get; }
        public ISingleton Singleton { get; }
        public ISingletonInstance SingletonInstance { get; }

        public InjectionService(ITransient transient, 
            IScoped scoped, ISingleton singleton,
            ISingletonInstance singletonInstance)
        {
            Transient = transient;
            Scoped = scoped;
            Singleton = singleton;
            SingletonInstance = singletonInstance;
        }
    }
}
