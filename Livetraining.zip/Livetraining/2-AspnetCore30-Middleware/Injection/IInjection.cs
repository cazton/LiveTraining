﻿using System;

namespace _1_AspnetCore30_Middleware.Injection
{
    public interface IInjection
    {
        Guid Id { get; }
    }

    public interface ITransient : IInjection
    {

    }

    public interface IScoped : IInjection
    {

    }

    public interface ISingleton : IInjection
    {

    }

    public interface ISingletonInstance : IInjection
    {

    }

    public class Injection : 
        ITransient, IScoped, ISingleton, ISingletonInstance
    {
        public Guid Id { get; }

        public Injection()
        {
            Id = Guid.NewGuid();
        }

        public Injection(Guid guid)
        {
            Id = guid;
        }
    }
}
