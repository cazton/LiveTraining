﻿namespace _1_AspnetCore30_Middleware.Models
{
    public class TrainingFilter
    {
        public string City { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
    }
}