﻿using System.Collections.Generic;

namespace _1_AspnetCore30_Middleware.Models
{
    public class Post : IPost
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }


        public List<Post> GetPosts()
        {
            return new List<Post>
            {
                new Post{ Id= 1, Name = "Dallas ", Age = 32},
                new Post{ Id= 2, Name = "Austin ", Age = 32},
                new Post{ Id= 3, Name = "John ", Age = 32},
                new Post{ Id= 4, Name = "Bill", Age = 32},
            };
        }
    }
}