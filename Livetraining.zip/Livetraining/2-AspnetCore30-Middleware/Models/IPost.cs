﻿using System.Collections.Generic;
using _1_AspnetCore30_Middleware.Controllers;

namespace _1_AspnetCore30_Middleware.Models
{
    public interface IPost
    {
        List<Post> GetPosts();
    }
}