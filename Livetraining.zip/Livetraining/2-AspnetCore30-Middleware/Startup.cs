using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using _1_AspnetCore30_Middleware.Injection;
using _1_AspnetCore30_Middleware.MiddlewareExtensions;
using _1_AspnetCore30_Middleware.Models;
using _1_AspnetCore30_Middleware.Repositories;
using _1_AspnetCore30_Middleware.Throttling;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace _1_AspnetCore30_Middleware
{
    public class Startup
    {
        private readonly string _caztonCorsPolicy = "CaztonCorsPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //CORS
            services.AddCors(x =>
            {
                //x.AddDefaultPolicy(
                //    policy => { 
                //        policy.AllowAnyOrigin()
                //        .AllowAnyMethod().AllowAnyHeader(); });
                x.AddPolicy("CaztonCorsPolicy",
                    policy =>
                    {
                        policy.WithOrigins("http://localhost:4200",
                                "https://chanderdhall.com")
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
                x.AddPolicy("ChanderCorsPolicy",
                    policy =>
                    {
                        policy.WithOrigins("http://localhost:5200",
                                "https://chanderdhall.com")
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            });

            services.AddScoped<IPost, Post>();
            try
            {

                services.AddTransient<ITransient, Injection.Injection>();
                services.AddSingleton<ISingleton, Injection.Injection>();
                services.AddSingleton<ISingletonInstance>
                    (new Injection.Injection(Guid.Empty));
                services.AddScoped<IScoped, Injection.Injection>();
                services.AddScoped<InjectionService, InjectionService>();
                services.AddScoped<ITrainingRepository, TrainingRepository>();
            }
            catch (Exception ex)
            {

            }

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
            IWebHostEnvironment env, ILogger<Startup> logger)
        {

            app.UseCors("CaztonCorsPolicy"); //Comment one & uncomment other
            //app.UseCors("ChanderCorsPolicy");

            //No. 1
            //app.UseMiddleware<ThrottlingMiddleware>();

            //No. 2
            app.UseThrottling();
            app.MapWhen(context =>
            {
                return context.Request.Query.ContainsKey("city");
            }, HandleCityInQueryString);

            //app.Use(async (context, next) =>
            //{
            //    logger.LogInformation($"{context.Request.Path} Request started");
            //    await next.Invoke();
            //    logger.LogInformation($"{context.Request.Path} Request ended");
            //});

            //app.Run(async context =>
            //{
            //    logger.LogInformation($"{context.Request.Path} Last middleware");
            //    await context.Response.WriteAsync("Last call");
            //});

            if (env.IsDevelopment())
            {
                //app.UseMiddleware<GlobalExceptionMiddleware>();
                app.UseGlobalExceptionHandler();
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }
            //CORS
            

            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapDefaultControllerRoute();
            });
        }

        private void HandleCityInQueryString(IApplicationBuilder app)
        {

            app.Run(async context =>
            {
                var queryDictionary =
                    Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(
                        context.Request.QueryString.ToString());

                await context.Response.WriteAsync($"City found {queryDictionary["city"]}");
            });
        }
    }
}
