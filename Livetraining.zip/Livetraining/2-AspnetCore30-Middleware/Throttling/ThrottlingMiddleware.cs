﻿using System.Collections.Generic;
using System.Threading.Tasks;
using _1_AspnetCore30_Middleware.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace _1_AspnetCore30_Middleware.Throttling
{
    public class ThrottlingMiddleware 
    {
        private readonly RequestDelegate _next;
        private static Dictionary<string, int> ipAddresses;

        public ThrottlingMiddleware(RequestDelegate next)
        {
            _next = next;
            if (ipAddresses == null)
            {
                ipAddresses = new Dictionary<string, int>();
            }
        }


        public async Task Invoke(HttpContext context,
            IPost posts, //Just to show
            ILogger<ThrottlingMiddleware> logger)
        {
            logger.Log(LogLevel.Information, "****** Throttling called ****");
            var ipAddress = context.Connection.RemoteIpAddress.ToString();

            //Logic
            await _next.Invoke(context);
        }
    }
}
